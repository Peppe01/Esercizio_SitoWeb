import UIKit


print()

class Notizie{
    var titolo : String
    var testo : String
    var data : String
    var autore: Autore
  

    init(titolo: String, testo: String, data: String, autore: Autore){
        self.titolo = titolo
        self.testo = testo
        self.data = data
        self.autore = autore
    }
    
    func toString() -> String{
        return "Titolo: \(self.titolo)\nTesto: \(self.testo)\nAutore: \(self.autore.toString())\nData: \(self.data)"
    }
}

class Video : Notizie{
    var urlVideo: String
    var durataVideo: Double

    init(titolo: String, testo: String, data: String, autore: Autore, urlVideo: String, durataVideo: Double) {
        self.urlVideo = urlVideo
        self.durataVideo = durataVideo
        
        super.init(titolo: titolo, testo: testo, data: data, autore: autore)
    }
    override func toString() -> String {
        return "Titolo Video: \(self.titolo)\nTesto: \(self.testo)\nUrl: \(self.urlVideo)\nDurata: \(self.durataVideo)\nAutore: \(self.autore.toString())\nData:\(self.data)"
        
    }
}

class gestoreNotizie {
    var articoli : [Notizie] = []
    
    
    func aggiungiArticolo (articolo: Notizie){
        self.articoli.append(articolo)
        print("Articolo aggiunto!\n\(articolo.toString())")
        }
    
    func mostraArticoliDaAutore (nome: String) -> [Notizie]{
        var notizie : [Notizie] = []
        for item in self.articoli {
            if item.autore.nome == nome{
                notizie.append(item)
                print(item.toString(),"\n")
            }
        }
        if notizie.count == 0 {
            print("Errore! Non abbiamo trovato nessun articolo dall'autore: \(nome)\n")
        }
        return notizie
    }
    
    func mostraNumArticoli() {
        var countVideo : Int = 0
        var countNews : Int = 0
        for item in self.articoli{
            if item is Video {
                countVideo = countVideo + 1
            }
        }
        countNews = self.articoli.count - countVideo
        print ("Articoli Video sono: \(countVideo) e gli Articoli scritti sono: \(countNews)")
    }
    
    func mostraUltimoArticolo () -> Notizie {
        let ultimoArticolo : Notizie = self.articoli[self.articoli.endIndex - 1]
        print("L'ultimo articolo è: \(ultimoArticolo.toString())")
        return ultimoArticolo
    }
    
}
    

class Autore{
    var nome : String
    var cognome : String
    var indirizzoWeb : String
    
    init(nome: String, cognome: String, indirizzoWeb: String) {
        self.nome = nome
        self.cognome = cognome
        self.indirizzoWeb = indirizzoWeb
    }
    func toString() -> String {
        return "Nome autore: \(self.nome), cognome autore: \(self.cognome), sito web: \(self.indirizzoWeb)"
    }
}


var gestore1 = gestoreNotizie()

var autore1 = Autore.init(nome: "Pippo", cognome: "Puglisi", indirizzoWeb: "www.pippopuglisi.com")
var autore2 = Autore.init(nome: "Turi", cognome: "Tazzamita", indirizzoWeb: "www.turiumuraturi.com")

var articolo1 = Notizie.init(titolo: "Essere Flex", testo: "Io sono Flex", data: "12-02-2011", autore: autore1)
var articolo2 = Notizie.init(titolo: "Io sono il Capo", testo: "U'CAPU!", data: "18-05-1973", autore: autore2)

var video1 = Video.init(titolo: "Il canto dell'Ornitorinco", testo: "Dov'è Perry?", data: "23-11-1998", autore: autore2, urlVideo: "http\\516x-jbw12/hqb10", durataVideo: 18.45)

var video2 = Video.init(titolo: "Astronomia", testo: "Coffin Meme", data: "10-03-2020", autore: autore1, urlVideo: "http\\xcv6787-187", durataVideo: 24.00)

gestore1.aggiungiArticolo(articolo: articolo1)
print()
gestore1.aggiungiArticolo(articolo: articolo2)
print()
gestore1.aggiungiArticolo(articolo: video1)
print()
gestore1.aggiungiArticolo(articolo: video2)
print()

gestore1.mostraArticoliDaAutore(nome: "Turi")
gestore1.mostraArticoliDaAutore(nome: "Pippo")

gestore1.mostraNumArticoli()

gestore1.mostraUltimoArticolo()
